import "./App.css";
import React from "react";
import Routing from "./Routes";

function App() {
  return <Routing />;
}

export default App;
