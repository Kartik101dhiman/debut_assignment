import React from "react";

const Texterror = (props) => {
  return <div className="error">{props.children}</div>;
};

export default Texterror;
