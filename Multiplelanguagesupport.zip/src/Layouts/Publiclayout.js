import React from "react";
import MUIBox from "../Component/MUIcomponent/MUIBox";

const Publiclayout = ({ children }) => {
  return <MUIBox className="publiclayoutcontainer">{children}</MUIBox>;
};

export default Publiclayout;
